**Instructions for Installing Microsoft Office:**

1. Copy the entire "Office Temporary" folder and paste it into the "C:" drive.
2. After pasting, copy the file path of the folder you just placed in the "C:" drive.
3. Open Command Prompt (CMD) in administrator mode. In the CMD window, type `cd` followed by a space, and then paste the file path you copied. Press Enter. {Do not close the CMD window}.
4. Next, open the "command" file provided by me, copy the command inside, and paste it into the open Command Prompt (CMD). Press Enter.

Microsoft Office will now begin the installation.